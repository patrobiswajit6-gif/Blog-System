package com.blog.entity;

import javax.persistence.*;

@Entity
@Table(name="comments")

public class Comment {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

private int id;

@ManyToOne
@JoinColumn(name="uid")

private User user;

private String comment;

public Comment(){}

public Comment(User user,String comment){
this.user=user;
this.comment=comment;
}

public int getId(){
return id;
}

public User getUser(){
return user;
}

public void setUser(User user){
this.user=user;
}

public String getComment(){
return comment;
}

public void setComment(String comment){
this.comment=comment;
}

}