package com.blog.entity;

import javax.persistence.*;

@Entity
@Table(name="users")

public class User {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

private int id;
private String password;

public User(){}

public User(String password){
this.password=password;
}

public int getId(){
return id;
}

public String getPassword(){
return password;
}

public void setPassword(String password){
this.password=password;
}
}