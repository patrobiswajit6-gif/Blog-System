package com.blog.main;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.blog.entity.*;
import com.blog.util.HibernateUtil;

public class MainApp {

public static void main(String[] args){

Session session = HibernateUtil.getSessionFactory().openSession();

Transaction tx = session.beginTransaction();

User u1 = new User("1234");

session.save(u1);

Blog b1 = new Blog("My First Blog","Hibernate is very useful",u1);

session.save(b1);

Comment c1 = new Comment(u1,"Nice Blog");

session.save(c1);

tx.commit();

session.close();

System.out.println("Blog system data inserted");

}
}